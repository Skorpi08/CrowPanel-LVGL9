#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *dreie;
    lv_obj_t *main;
    lv_obj_t *obj0;
    lv_obj_t *obj0__x_led_6;
    lv_obj_t *obj0__state_14;
    lv_obj_t *obj0__state_15;
    lv_obj_t *obj1;
    lv_obj_t *obj1__x_led_6;
    lv_obj_t *obj1__state_14;
    lv_obj_t *obj1__state_15;
    lv_obj_t *obj2;
    lv_obj_t *obj2__x_led_6;
    lv_obj_t *obj2__state_14;
    lv_obj_t *obj2__state_15;
    lv_obj_t *obj3;
    lv_obj_t *obj3__x_led_6;
    lv_obj_t *obj3__state_14;
    lv_obj_t *obj3__state_15;
    lv_obj_t *obj4;
    lv_obj_t *obj4__x_led_6;
    lv_obj_t *obj4__state_14;
    lv_obj_t *obj4__state_15;
    lv_obj_t *obj5;
    lv_obj_t *obj5__x_led_6;
    lv_obj_t *obj5__state_14;
    lv_obj_t *obj5__state_15;
    lv_obj_t *obj6;
    lv_obj_t *obj6__x_led_6;
    lv_obj_t *obj6__state_14;
    lv_obj_t *obj6__state_15;
    lv_obj_t *obj7;
    lv_obj_t *obj7__x_led_6;
    lv_obj_t *obj7__state_14;
    lv_obj_t *obj7__state_15;
    lv_obj_t *obj8;
    lv_obj_t *obj8__x_led_6;
    lv_obj_t *obj8__state_14;
    lv_obj_t *obj8__state_15;
    lv_obj_t *obj9;
    lv_obj_t *obj9__x_led_6;
    lv_obj_t *obj9__state_14;
    lv_obj_t *obj9__state_15;
    lv_obj_t *obj10;
    lv_obj_t *obj10__x_led_6;
    lv_obj_t *obj10__state_14;
    lv_obj_t *obj10__state_15;
    lv_obj_t *obj11;
    lv_obj_t *obj11__x_led_6;
    lv_obj_t *obj11__state_14;
    lv_obj_t *obj11__state_15;
    lv_obj_t *obj12;
    lv_obj_t *obj12__x_led_6;
    lv_obj_t *obj12__state_14;
    lv_obj_t *obj12__state_15;
    lv_obj_t *obj13;
    lv_obj_t *obj13__x_led_6;
    lv_obj_t *obj13__state_14;
    lv_obj_t *obj13__state_15;
    lv_obj_t *obj14;
    lv_obj_t *obj14__x_led_6;
    lv_obj_t *obj14__state_14;
    lv_obj_t *obj14__state_15;
    lv_obj_t *obj15;
    lv_obj_t *obj15__x_led_6;
    lv_obj_t *obj15__state_14;
    lv_obj_t *obj15__state_15;
    lv_obj_t *obj16;
    lv_obj_t *obj16__x_led_6;
    lv_obj_t *obj16__state_14;
    lv_obj_t *obj16__state_15;
    lv_obj_t *obj17;
    lv_obj_t *obj17__x_led_6;
    lv_obj_t *obj17__state_14;
    lv_obj_t *obj17__state_15;
    lv_obj_t *bottom_panel1;
    lv_obj_t *left;
    lv_obj_t *tabe1;
    lv_obj_t *state_1;
    lv_obj_t *panel_dro_1;
    lv_obj_t *tabe2;
    lv_obj_t *tabe3;
    lv_obj_t *tabe4;
    lv_obj_t *tabe5;
    lv_obj_t *right;
    lv_obj_t *state_2;
    lv_obj_t *panel_dro_2;
    lv_obj_t *obj18;
    lv_obj_t *cont_right;
    lv_obj_t *cont_left;
    lv_obj_t *state;
    lv_obj_t *panel_dro;
    lv_obj_t *right_panel;
    lv_obj_t *left_panel;
    lv_obj_t *bottom_panel;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_DREIE = 1,
    SCREEN_ID_MAIN = 2,
};

void create_screen_dreie();
void delete_screen_dreie();
void tick_screen_dreie();

void create_screen_main();
void delete_screen_main();
void tick_screen_main();

void create_user_widget_dro(lv_obj_t *parent_obj, void *flowState, int startWidgetIndex);
void tick_user_widget_dro(void *flowState, int startWidgetIndex);

void create_screen_by_id(enum ScreensEnum screenId);
void delete_screen_by_id(enum ScreensEnum screenId);
void tick_screen_by_id(enum ScreensEnum screenId);
void tick_screen(int screen_index);

void create_screens();


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/